
$(window).load(function() {
    setTimeout(function(){        
    $(".se-pre-con").fadeOut("slow");;
    }, 2500);
});